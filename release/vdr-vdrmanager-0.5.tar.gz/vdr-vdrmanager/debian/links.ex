usr/share/vdr-plugin-vdrmanager/vdrmanager    var/lib/vdr/plugins/vdrmanager
