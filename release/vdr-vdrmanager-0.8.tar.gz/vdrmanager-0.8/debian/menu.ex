?package(vdr-plugin-vdrmanager):needs="X11|text|vc|wm" section="Applications/see-menu-manual"\
  title="vdr-plugin-vdrmanager" command="/usr/bin/vdr-plugin-vdrmanager"
